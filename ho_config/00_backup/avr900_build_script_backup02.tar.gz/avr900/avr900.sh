#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_directory=`pwd`
temp_current_path=$PATH
temp_default_module=anydata-lazydog
logfile_modem_path=.

#--------------------------------------------------------------------------------------------------

# Set Path
source ~/work_config/avr900/setpath.sh

#--------------------------------------------------------------------------------------------------

echo current_build_place=$current_build_place
echo ARMLMD_LICENSE_FILE=$ARMLMD_LICENSE_FILE
echo "**************************************************************************"
echo "*              S e l e c t   B u i l d   O p e r a t o r                 *"
echo "*========================================================================*"
echo "*  1 or android   : android build(Linux Kernel)                          *"
echo "*  2 or boot      : boot_images build                                    *"
echo "*  3 or dsps      : dsps_proc build                                      *"
echo "*  4 or lpass     : lpass_proc build                                     *"
echo "*  5 or modem     : modem_proc build                                     *"
echo "*  6 or common    : common build(NON-HLOS)                               *"
echo "*  7 or rpm       : rpm_proc build                                       *"
echo "*  8 or trustzone : trustzone_images build                               *"
echo "*  9 or make_images or em :                                              *"
echo "*  10 or cp_images        :                                              *"
echo "*  0 or all       :                                                      *"
#echo "*------------------------------------------------------------------------*"
#echo "*  virtual/kernel, virtual/bootloader, lk                                *"
#echo "*------------------------------------------------------------------------*"
#echo "*  mclean or mc   : module clean                                         *"
#echo "*  mbuild or mb   : module build                                         *"
#echo "*  mcb            : module build and clean                               *"
#echo "*  cleanall       : remove apps_proc/oe-core/build/tmp-eglibc            *"
echo "*------------------------------------------------------------------------*"
#echo "*  em - Emergency Download Images                                        *"
echo "*  99 or permission : Permission Setting(*.pl,*.cmd,*.sh)                *"
echo "*------------------------------------------------------------------------*"
echo "*  x: Exit                                                               *"
echo "*========================================================================*"
echo "Select : "
read Choice_Command
echo "**************************************************************************"

# =============================================================================

if [ -z $Choice_Command  ] ; then
	Choice_Command='x'
fi

# =============================================================================

if [ $Choice_Command == 'x' ] || [ $Choice_Command == 'X' ] ; then
	echo Exit ........
fi

# =============================================================================

if [ $Choice_Command == '0' ] || [ $Choice_Command == 'all' ] ; then
	# --------------------------------------------
	#export PATH=$PYTHON266_PATH:$PATH

	echo All of the source Compile Start ........
	# --------------------------------------------
	echo Bootloader Compile Start ........

	logfile_name=$temp_current_directory/work_all.log
	logfile_name_old=$temp_current_directory/work_all.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	# --------------------------------------------
	echo android Compile ........
	export PATH=$PYTHON266_PATH:$PATH
	cd $logfile_modem_path/src/LINUX/android
	if [ -f ./build.sh ]; then
		. build.sh msm8960 -k msm8960-perf_defconfig $* | tee -a $logfile_name
	fi
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo boot_images Compile ........
	export PATH=$PYTHON266_PATH:$PATH
	cd $logfile_modem_path/src/boot_images/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh sbl1 sbl2 sbl3 jsdcc emmcbld BUILD_ID=AAABQNBY | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo dsps_proc Compile ........
	export PATH=$PYTHON266_PATH:$PATH
	cd $logfile_modem_path/src/dsps_proc/core/bsp/build
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh sensorsimg BUILD_ID=DSPSBLDZ | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo lpass_proc Compile ........
	export PATH=$PYTHON266_PATH:$PATH
	cd $logfile_modem_path/src/lpass_proc
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	make clean_hash | tee -a $logfile_name
	make hash | tee -a $logfile_name
	make split_hash | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo common Compile ........
	export PATH=$PYTHON266_PATH:$PATH
	cd $logfile_modem_path/src/common/build
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	rm -rf update_common*.log | tee -a $logfile_name
	python update_common_info.py | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo rpm_proc Compile ........
	export PATH=$PYTHON266_PATH:$PATH
	cd $logfile_modem_path/src/rpm_proc/build
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo trustzone_images Compile ........
	export PATH=$PYTHON266_PATH:$PATH
	cd $logfile_modem_path/src/trustzone_images/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh CHIPSET=msm8960 BUILD_ID=AAABQNBY tz tzapps sampleapp | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo modem_proc Compile ........
	export PATH=$PYTHON273_PATH:$PATH
	export HEXAGON_ROOT=$HOME/Qualcomm/HEXAGON_Tools
	export HEXAGON_RTOS_RELEASE=3.0.10
	export HEXAGON_Q6VERSION=v4
	export HEXAGON_IMAGE_ENTRY=0x89000000
	cd $logfile_modem_path/src/modem_proc/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh mpss BUILD_ID=AAAAANAZ | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path
	
	# --------------------------------------------
	echo All of the source Compile Completed ........
fi

# =============================================================================

if [ $Choice_Command == 'clean' ] ; then
	#export PATH=$PYTHON273_PATH:$PATH
	export PATH=$PYTHON266_PATH:$PATH

	echo android Clean Start ........

	logfile_name=$temp_current_directory/work_clean_proc.log
	logfile_name_old=$temp_current_directory/work_clean_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/LINUX/android
	if [ -f ./build.sh ]; then
		. build.sh msm8960 -k msm8960-perf_defconfig -c $* | tee -a $logfile_name
		echo Build completed at $(date) | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo android Clean Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'kernel' ] ; then
	#export PATH=$PYTHON273_PATH:$PATH
	export PATH=$PYTHON266_PATH:$PATH

	echo Kernel Compile Start ........

	logfile_name=$temp_current_directory/work_kernel_proc.log
	logfile_name_old=$temp_current_directory/work_kernel_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/LINUX/android
	if [ -f ./build.sh ]; then
		. build.sh msm8960 -k msm8960-perf_defconfig -m bootimage $* | tee -a $logfile_name
		echo Build completed at $(date) | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Kernel Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == '1' ] || [ $Choice_Command == 'android' ] ; then
	#export PATH=$PYTHON273_PATH:$PATH
	export PATH=$PYTHON266_PATH:$PATH

	echo android Compile Start ........

	logfile_name=$temp_current_directory/work_android_proc.log
	logfile_name_old=$temp_current_directory/work_android_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/LINUX/android
	if [ -f ./build.sh ]; then
		. build.sh msm8960 -k msm8960-perf_defconfig $* | tee -a $logfile_name
		echo Build completed at $(date) | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo android Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == '2' ] || [ $Choice_Command == 'boot' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo boot_images Compile Start ........

	logfile_name=$temp_current_directory/work_boot_images.log
	logfile_name_old=$temp_current_directory/work_boot_images.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/boot_images/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh sbl1 sbl2 sbl3 jsdcc emmcbld BUILD_ID=AAABQNBY | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo boot_images Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == '3' ] || [ $Choice_Command == 'dsps' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo dsps Compile Start ........

	logfile_name=$temp_current_directory/work_dsps_proc.log
	logfile_name_old=$temp_current_directory/work_dsps_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/dsps_proc/core/bsp/build
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh sensorsimg BUILD_ID=DSPSBLDZ | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo dsps Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == '4' ] || [ $Choice_Command == 'lpass' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo lpass Compile Start ........

	logfile_name=$temp_current_directory/work_lpass_proc.log
	logfile_name_old=$temp_current_directory/work_lpass_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/lpass_proc
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	make clean_hash | tee -a $logfile_name
	make hash | tee -a $logfile_name
	make split_hash | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo lpass Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == '5' ] || [ $Choice_Command == 'modem' ] ; then
	export PATH=$PYTHON273_PATH:$PATH
	export HEXAGON_ROOT=$HOME/Qualcomm/HEXAGON_Tools
	export HEXAGON_RTOS_RELEASE=3.0.10
	export HEXAGON_Q6VERSION=v4
	export HEXAGON_IMAGE_ENTRY=0x89000000

	echo modem Compile Start ........

	logfile_name=$temp_current_directory/work_modem_proc.log
	logfile_name_old=$temp_current_directory/work_modem_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/modem_proc/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh mpss BUILD_ID=AAAAANAZ | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo modem Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == '6' ] || [ $Choice_Command == 'common' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo common NON-HLOS Compile Start ........

	logfile_name=$temp_current_directory/work_common_proc.log
	logfile_name_old=$temp_current_directory/work_common_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/common/build
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	rm -rf update_common*.log | tee -a $logfile_name
	python update_common_info.py | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo common NON-HLOS  Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == '7' ] || [ $Choice_Command == 'rpm' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo rpm Compile Start ........

	logfile_name=$temp_current_directory/work_rpm_proc.log
	logfile_name_old=$temp_current_directory/work_rpm_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/rpm_proc/build
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo rpm Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == '8' ] || [ $Choice_Command == 'trustzone' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo trustzone Compile Start ........

	logfile_name=$temp_current_directory/work_trustzone_proc.log
	logfile_name_old=$temp_current_directory/work_trustzone_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/trustzone_images/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh CHIPSET=msm8960 BUILD_ID=AAABQNBY tz tzapps sampleapp | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo trustzone Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'b' ] || [ $Choice_Command == 'bootimg' ] ; then
	#export PATH=$PYTHON273_PATH:$PATH
	export PATH=$PYTHON266_PATH:$PATH

	echo android Bootimg Compile Start ........

	logfile_name=$temp_current_directory/work_android_bootimg_proc.log
	logfile_name_old=$temp_current_directory/work_android_bootimg_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/src/LINUX/android
	if [ -f ./build.sh ]; then
		#. build.sh msm8960 -k msm8960-perf_defconfig $* | tee -a $logfile_name
		. build.sh msm8960 -k msm8960-perf_defconfig -i bootimg $* | tee -a $logfile_name
		echo Build completed at $(date) | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo android Bootimg Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

#if [ $Choice_Command == 'make_images' ] ; then
if [ $Choice_Command == '9' ] || [ $Choice_Command == 'em' ] || [ $Choice_Command == 'make_images' ] ; then

	echo Copy - Emergency Download Images Start ........

	if [ -d $temp_current_directory/build_images/images ]; then
		echo Erase the Emergency_Download_Images folder ...
		rm -rf $temp_current_directory/build_images/images
	fi
	
	mkdir $temp_current_directory/build_images/images

	cp ./src/boot_images/build/ms/bin/AAABQNBY/sbl1.mbn ./src/boot_images/build/ms/bin/AAABQNBY/sbl2.mbn ./src/boot_images/build/ms/bin/AAABQNBY/sbl3.mbn ./src/boot_images/core/storage/tools/jsdcc/partition_load_pt/
	cp ./src/boot_images/build/ms/bin/AAABQNBY/sbl1.mbn ./src/boot_images/build/ms/bin/AAABQNBY/sbl2.mbn ./src/boot_images/build/ms/bin/AAABQNBY/sbl3.mbn ./src/common/build/
	cp ./src/rpm_proc/build/ms/bin/AAAAANAAR/rpm.mbn ./src/boot_images/core/storage/tools/jsdcc/partition_load_pt/
	cp ./src/rpm_proc/build/ms/bin/AAAAANAAR/rpm.mbn ./src/common/build/
	cp ./src/trustzone_images/build/ms/bin/AAABQNBY/tz.mbn ./src/boot_images/core/storage/tools/jsdcc/partition_load_pt/
	cp ./src/trustzone_images/build/ms/bin/AAABQNBY/tz.mbn ./src/common/build/
	cp ./src/trustzone_images/build/ms/bin/AAABQNBY/sampleapp.mbn ./src/common/build/
	cp ./src/trustzone_images/build/ms/bin/AAABQNBY/tzapps.mbn ./src/common/build/
	cp ./src/wcnss_proc/build/ms/bin/8960/wcnss.mbn ./src/common/build/
	cp ./src/modem_proc/build/ms/bin/AAAAANAZ/dsp1.mbn ./src/common/build/
	cp ./src/modem_proc/build/ms/bin/AAAAANAZ/dsp2.mbn ./src/common/build/
	cp ./src/lpass_proc/hashing/build/ms/bin/AAAAANAA/qdsp6_fw.mbn ./src/common/build/
	cd ./src/boot_images/core/storage/tools/jsdcc/partition_load_pt/ 
	python singleimage.py -x singleimage_partition_8960.xml

	cd $temp_current_directory
	cp ./src/boot_images/core/storage/tools/jsdcc/partition_load_pt/singleimage.bin $temp_current_directory/build_images/images/8960_msimage.mbn
	cp ./src/boot_images/build/ms/bin/AAABQNBY/MPRG8960.hex $temp_current_directory/build_images/images/
	cd ./src/LINUX/android/out/target/product/msm8960
	cp boot.img bootloader emmc_appsboot.mbn persist.img cache.img ramdisk.img ramdisk-recovery.img recovery.img system.img userdata.img $temp_current_directory/src/common/build/
	cp $temp_current_directory/src/dsps_proc/build/ms/bin/DSPSBLDZ/dsps.mbn $temp_current_directory/src/common/build/
	cd $temp_current_directory/src/common/build
	python ptool.py -x partition.xml
	cp rawprogram0.xml patch0.xml gpt_main0.bin gpt_both0.bin gpt_backup0.bin $temp_current_directory/build_images/images/
	python checksparse.py -i rawprogram0.xml -o rawprogram0_unsparse.xml -s $temp_current_directory/src/common/build

	cd $temp_current_directory/src/common/build
	cp cache.img dsps.mbn gpt_backup0.bin gpt_both0.bin gpt_main0.bin patch0.xml rawprogram0_unsparse.xml system.img userdata.img boot.img bootloader dsp1.mbn dsp2.mbn emmc_appsboot.mbn persist.img recovery.img tz.mbn rpm.mbn sbl1.mbn sbl2.mbn sbl3.mbn NON-HLOS.bin wcnss.mbn $temp_current_directory/build_images/images
	rm -rf $temp_current_directory/build_images/images/sparse_images/

	cd $temp_current_directory

	echo Copy - Emergency Download Images Completed ........

fi

# =============================================================================

if [ $Choice_Command == '10' ] || [ $Choice_Command == 'cp_images' ] ; then

	echo Copy - Copy Images Start ........

	cd $temp_current_directory/src/common/build
	#cp *.img *.mbn *.bin *.xml $temp_current_directory/build_images/images
	cp * $temp_current_directory/build_images/images
	rm -rf $temp_current_directory/build_images/images/sparse_images/

	cd $temp_current_directory

	echo Copy - Copy Images Completed ........

fi

# =============================================================================
# =============================================================================
# =============================================================================

if [ $Choice_Command == 'mc' ] || [ $Choice_Command == 'mclean' ] ; then

	echo Module Clean Start ........

	echo "Input the module name : "
	read Ho_Module_Name

	if [ "$Ho_Module_Name" = "" ] ; then
		Ho_Module_Name=$temp_default_module
	fi

	Ho_Build_Log_Name=$Ho_Module_Name
	if [ "$Ho_Build_Log_Name" = "virtual/kernel" ] ; then
		Ho_Build_Log_Name=kernel
	fi
	if [ "$Ho_Build_Log_Name" = "virtual/bootloader" ] ; then
		Ho_Build_Log_Name=bootloader
	fi

	# --------------------------------------------

	if [ "$Ho_Module_Name" = "kernel" ] ; then
		Ho_Module_Name=virtual/kernel
	fi

	if [ "$Ho_Module_Name" = "bootloader" ] ; then
		Ho_Module_Name=virtual/bootloader
	fi

	# --------------------------------------------

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_clean_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_clean_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake -c cleanall $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Clean $Ho_Module_Name Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'mb' ] || [ $Choice_Command == 'mbuild' ] ; then

	echo Module Build Start ........

	echo "Input the module name : "
	read Ho_Module_Name

	if [ "$Ho_Module_Name" = "" ] ; then
		Ho_Module_Name=$temp_default_module
	fi

	Ho_Build_Log_Name=$Ho_Module_Name
	if [ "$Ho_Build_Log_Name" = "virtual/kernel" ] ; then
		Ho_Build_Log_Name=kernel
	fi
	if [ "$Ho_Build_Log_Name" = "virtual/bootloader" ] ; then
		Ho_Build_Log_Name=bootloader
	fi

	# --------------------------------------------

	if [ "$Ho_Module_Name" = "kernel" ] ; then
		Ho_Module_Name=virtual/kernel
	fi

	if [ "$Ho_Module_Name" = "bootloader" ] ; then
		Ho_Module_Name=virtual/bootloader
	fi

	# --------------------------------------------

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Build $Ho_Module_Name Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'mcb' ] ; then

	echo Module Clean and Build Start ........

	echo "Input the module name : "
	read Ho_Module_Name

	if [ "$Ho_Module_Name" = "" ] ; then
		Ho_Module_Name=$temp_default_module
	fi

	Ho_Build_Log_Name=$Ho_Module_Name
	if [ "$Ho_Build_Log_Name" = "virtual/kernel" ] ; then
		Ho_Build_Log_Name=kernel
	fi
	if [ "$Ho_Build_Log_Name" = "virtual/bootloader" ] ; then
		Ho_Build_Log_Name=bootloader
	fi

	# --------------------------------------------

	if [ "$Ho_Module_Name" = "kernel" ] ; then
		Ho_Module_Name=virtual/kernel
	fi

	if [ "$Ho_Module_Name" = "bootloader" ] ; then
		Ho_Module_Name=virtual/bootloader
	fi

	# --------------------------------------------

	echo Module Clean Start ........

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_clean_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_clean_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake -c cleanall $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Clean $Ho_Module_Name Completed ........

	cd $temp_current_directory

	# --------------------------------------------

	echo Module Build Start ........

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Build $Ho_Module_Name Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'cleanalllllllllllllllllllllllll' ] ; then

	echo All of Module Clean Start ........

	cd $logfile_modem_path/apps_proc/oe-core
	rm -rf ./build/tmp-eglibc
	mkdir ./build/tmp-eglibc

	echo All of Module Clean Completed ........

	cd $temp_current_directory
fi

# =============================================================================
# =============================================================================
# =============================================================================

if [ $Choice_Command == '99' ] || [ $Choice_Command == 'permission' ] ; then

	echo Permission Setting Start ........
	#cd $logfile_modem_path

	find . -name "*.sh" -exec sudo chmod a+x {} \;
	find . -name "*.pl" -exec sudo chmod a+x {} \;
	find . -name "*.cmd" -exec sudo chmod a+x {} \;
	#find . -name "*.py" -exec sudo chmod a+x {} \;

	echo Permission Setting Completed ........

fi

# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
