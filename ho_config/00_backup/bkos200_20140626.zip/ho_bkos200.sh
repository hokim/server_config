#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_project_name=bkos200
temp_current_time=`date +%Y%m%d_%H%M%S`
temp_current_directory=`pwd`
temp_current_path=$PATH
temp_default_manifest=ssh://ottsrc.kaon:29418/marvell/manifest-combi-bkos200
temp_config_file=./vendor/kaon/BKO-S200/bkos200.mk
temp_make_update_path=./00_Update
logfile_path=.

# =============================================================================
# HO_CHANGE_BKOS200_CONFIG_MP_
# -----------------------------------------------------------------------------
HO_CHANGE_BKOS200_CONFIG_MP_() {

	sed -i 's/#PRODUCT_DEFAULT_DEV_CERTIFICATE/PRODUCT_DEFAULT_DEV_CERTIFICATE/g' $temp_config_file
	sed -i 's/KAON_MV88DE3100_SDK := bg2ct.bkos200.emmc.gtvv4.cfg/KAON_MV88DE3100_SDK := bg2ct.bkos200_mp.emmc.gtvv4.cfg/g' $temp_config_file
	sed -i 's/KAON_MV88DE3100_SDK := bg2ct.bkos200.emmc_ota.gtvv4.cfg/KAON_MV88DE3100_SDK := bg2ct.bkos200_mp.emmc.gtvv4.cfg/g' $temp_config_file
	return

}

# =============================================================================
# HO_CHANGE_BKOS200_CONFIG_OTA_
# -----------------------------------------------------------------------------
HO_CHANGE_BKOS200_CONFIG_OTA_() {

	sed -i 's/#PRODUCT_DEFAULT_DEV_CERTIFICATE/PRODUCT_DEFAULT_DEV_CERTIFICATE/g' $temp_config_file
	sed -i 's/KAON_MV88DE3100_SDK := bg2ct.bkos200.emmc.gtvv4.cfg/KAON_MV88DE3100_SDK := bg2ct.bkos200_ota.emmc.gtvv4.cfg/g' $temp_config_file
	sed -i 's/KAON_MV88DE3100_SDK := bg2ct.bkos200_mp.emmc.gtvv4.cfg/KAON_MV88DE3100_SDK := bg2ct.bkos200_ota.emmc.gtvv4.cfg/g' $temp_config_file
	return

}

# =============================================================================
# HO_CHANGE_BKOS200_CONFIG_NONOTP_
# -----------------------------------------------------------------------------
HO_CHANGE_BKOS200_CONFIG_NONOTP_() {

	sed -i 's/#PRODUCT_DEFAULT_DEV_CERTIFICATE/PRODUCT_DEFAULT_DEV_CERTIFICATE/g' $temp_config_file
	sed -i 's/KAON_MV88DE3100_SDK := bg2ct.bkos200_mp.emmc.gtvv4.cfg/KAON_MV88DE3100_SDK := bg2ct.bkos200.emmc.gtvv4.cfg/g' $temp_config_file
	sed -i 's/KAON_MV88DE3100_SDK := bg2ct.bkos200_ota.emmc.gtvv4.cfg/KAON_MV88DE3100_SDK := bg2ct.bkos200.emmc.gtvv4.cfg/g' $temp_config_file
	return

}

# =============================================================================
# HO_HOKIM_UPDATE_ZIP_
# -----------------------------------------------------------------------------
HO_HOKIM_UPDATE_ZIP_() {

	echo HO_HOKIM_UPDATE_ZIP_ ........
	# --------------------------------------------
	cd $logfile_path

	if [ -d $temp_make_update_path ]; then
		rm -rf $temp_make_update_path
	fi
	mkdir $temp_make_update_path
	if [ -f ./out/target/product/BKO-S200/system/usr/skb/version.txt ]; then
		cp ./out/target/product/BKO-S200/system/usr/skb/version.txt $temp_make_update_path/
	fi
	if [ -f ./out/target/product/BKO-S200/bkos200-*.* ]; then
		cp ./out/target/product/BKO-S200/bkos200-*.* $temp_make_update_path/
		mv $temp_make_update_path/bkos200-*.* $temp_make_update_path/update.zip
	fi
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_CHECK_INIT_STATUS_
# -----------------------------------------------------------------------------
HO_CHECK_INIT_STATUS_() {

	# --------------------------------------------
	cd $logfile_path
	# --------------------------------------------
	#if [ "$TARGET_PRODUCT" != "bkos200" ] ; then
		# --------------------------------------------
		echo Init Script Start ........
		if [ -f ./build/envsetup.sh ]; then
			. build/envsetup.sh
			lunch 12
		else
			echo 
			echo Please Check The Source!!!
			exit
		fi
	#fi
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_ENV_INIT_
# -----------------------------------------------------------------------------
HO_BUILD_ENV_INIT_() {

	echo HO_BUILD_ENV_INIT_ ........
	# --------------------------------------------
	cd $logfile_path
	# --------------------------------------------
	if [ -f ./build/envsetup.sh ]; then
		. build/envsetup.sh
		lunch 12
	else
		echo 
		echo Please Check The Source!!!
		exit
	fi
	echo Init Script Completed ........
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_LINUX_ALL_
# -----------------------------------------------------------------------------
HO_BUILD_LINUX_ALL_() {

	echo HO_BUILD_LINUX_ALL_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_kernel_proc.log
	logfile_name_old=$temp_current_directory/build_kernel_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Kernel Compile Started at $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	make linux_all 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo Kernel Compile Completed at $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_AMP_CORE_
# -----------------------------------------------------------------------------
HO_BUILD_AMP_CORE_() {

	echo HO_BUILD_AMP_CORE_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_amp_core_proc.log
	logfile_name_old=$temp_current_directory/build_amp_core_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo AMP Core Compile Started at $(date) ........ | tee -a $logfile_name
	make amp_core 2>&1 | tee -a $logfile_name
	echo AMP Core Compile Completed at $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_SDK_
# -----------------------------------------------------------------------------
HO_BUILD_SDK_() {

	echo HO_BUILD_SDK_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_mv88de3100_sdk_proc.log
	logfile_name_old=$temp_current_directory/build_mv88de3100_sdk_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo MV88DE3100 SDK Compile Started at $(date) ........ | tee -a $logfile_name
	make mv88de3100_sdk 2>&1 | tee -a $logfile_name
	echo MV88DE3100 SDK Compile Completed at $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_GOOGLETV_
# -----------------------------------------------------------------------------
HO_BUILD_GOOGLETV_() {

	echo HO_BUILD_GOOGLETV_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_googletv_proc.log
	logfile_name_old=$temp_current_directory/build_googletv_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo GoogleTV Compile Started $(date) ........ | tee -a $logfile_name
	make -j8 2>&1 | tee -a $logfile_name
	echo GoogleTV Compile Completed $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_EMMC_
# -----------------------------------------------------------------------------
HO_BUILD_EMMC_() {

	echo HO_BUILD_EMMC_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_emmc_proc.log
	logfile_name_old=$temp_current_directory/build_emmc_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo eMMC Image Make Started $(date) ........ | tee -a $logfile_name
	make image -j8 2>&1 | tee -a $logfile_name
	echo eMMC Image Make Completed $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_OTA_PACKAGE_
# -----------------------------------------------------------------------------
HO_BUILD_OTA_PACKAGE_() {

	echo HO_BUILD_OTA_PACKAGE_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_ota_package_proc.log
	logfile_name_old=$temp_current_directory/build_ota_package_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo OTA Package Compile Started $(date) ........ | tee -a $logfile_name
	make otapackage -j8 2>&1 | tee -a $logfile_name
	echo OTA Package Compile Completed $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_MP_
# -----------------------------------------------------------------------------
HO_BUILD_MP_() {

	echo HO_BUILD_MP_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_mp_proc.log
	logfile_name_old=$temp_current_directory/build_mp_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Mass Production Compile Started $(date) ........ | tee -a $logfile_name
	make mp_imgset -j8 2>&1 | tee -a $logfile_name
	make mp_signset -j8 2>&1 | tee -a $logfile_name
	echo Mass Production Compile Completed $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_REPO_INIT_
# -----------------------------------------------------------------------------
HO_REPO_INIT_() {

	echo HO_REPO_INIT_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_init_proc.log
	logfile_name_old=$temp_current_directory/repo_init_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Repo Init Started $(date) ........ | tee -a $logfile_name
	repo init -u $temp_default_manifest 2>&1 | tee -a $logfile_name
	echo Repo Init Completed $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_REPO_SYNC_
# -----------------------------------------------------------------------------
HO_REPO_SYNC_() {

	echo HO_REPO_SYNC_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_sync_proc.log
	logfile_name_old=$temp_current_directory/repo_sync_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Repo Sync Started $(date) ........ | tee -a $logfile_name
	repo sync 2>&1 | tee -a $logfile_name
	echo Repo Sync Completed $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_REPO_CLEAN_
# -----------------------------------------------------------------------------
HO_REPO_CLEAN_() {

	echo v ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_clean_proc.log
	logfile_name_old=$temp_current_directory/repo_clean_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Repo Clean Started $(date) ........ | tee -a $logfile_name
	repo forall -c git clean -d -f 2>&1 | tee -a $logfile_name
	repo forall -c git reset --hard HEAD 2>&1 | tee -a $logfile_name
	repo forall -c git checkout m/master 2>&1 | tee -a $logfile_name
	repo sync 2>&1 | tee -a $logfile_name
	echo Repo Clean Completed $(date) ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_BUILD_ALL_
# -----------------------------------------------------------------------------
HO_BUILD_ALL_() {

	echo HO_BUILD_ALL_ ........
	# --------------------------------------------
	cd $logfile_path
	# --------------------------------------------
	HO_BUILD_LINUX_ALL_
	HO_BUILD_AMP_CORE_
	HO_BUILD_SDK_
	HO_BUILD_GOOGLETV_
	HO_BUILD_EMMC_
	HO_BUILD_OTA_PACKAGE_
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# HO_REPO_BRANCH_
# -----------------------------------------------------------------------------
HO_REPO_BRANCH_() {

	echo HO_REPO_BRANCH_ ........
	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_branch_proc.log
	logfile_name_old=$temp_current_directory/repo_branch_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Branch Set Start ........ 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo "TVStorm repository ***********************" 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo "repo start master kaon/googletv/v4-rc-81358" 2>&1 | tee -a $logfile_name
	repo start master kaon/googletv/v4-rc-81358 2>&1 | tee -a $logfile_name
	echo "repo start master kaon/bkos200" 2>&1 | tee -a $logfile_name
	repo start master kaon/bkos200 2>&1 | tee -a $logfile_name
	echo "repo start master kaon/marvell/sdk-marvell" 2>&1 | tee -a $logfile_name
	repo start master kaon/marvell/sdk-marvell 2>&1 | tee -a $logfile_name
	echo "repo start master tvstorm/prebuilts" 2>&1 | tee -a $logfile_name
	repo start master tvstorm/prebuilts 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo "Kaon repository ***********************" 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo "repo start mrvl/bg2ct/OTA01 marvell/mv88de3100_sdk" 2>&1 | tee -a $logfile_name
	repo start mrvl/bg2ct/OTA01 marvell/mv88de3100_sdk 2>&1 | tee -a $logfile_name
	echo "repo start mrvl/bg2ct/OTA01 marvell/ampsdk" 2>&1 | tee -a $logfile_name
	repo start mrvl/bg2ct/OTA01 marvell/ampsdk 2>&1 | tee -a $logfile_name
	echo "repo start mrvl/bg2ct/OTA01 marvell/linux" 2>&1 | tee -a $logfile_name
	repo start mrvl/bg2ct/OTA01 marvell/linux 2>&1 | tee -a $logfile_name
	echo Branch Set Completed ........ 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	return

}

# =============================================================================
# 
# -----------------------------------------------------------------------------

if [ -z $1 ]; then

	echo .

else

	if [ $1 == 'repo' ]; then
		HO_REPO_INIT_
		HO_REPO_SYNC_
		exit
	fi

	if [ $1 == 'full' ]; then
		HO_REPO_INIT_
		HO_REPO_SYNC_
		HO_REPO_BRANCH_
		HO_BUILD_ENV_INIT_
		HO_BUILD_ALL_
		exit
	fi

	if [ $1 == 'full_mppppppppppp' ]; then
		HO_REPO_INIT_
		HO_REPO_SYNC_
		HO_REPO_BRANCH_

		# MP
		HO_CHANGE_BKOS200_CONFIG_MP_

		HO_BUILD_ENV_INIT_
		HO_BUILD_ALL_
		HO_BUILD_MP_
		exit
	fi

	if [ $1 == 'releaseeeeeeeeeeee' ]; then
		HO_REPO_INIT_
		HO_REPO_SYNC_
		HO_REPO_BRANCH_

		# OTA
		HO_CHANGE_BKOS200_CONFIG_OTA_

		HO_BUILD_ENV_INIT_
		HO_BUILD_ALL_
		exit
	fi

fi

#--------------------------------------------------------------------------------------------------

#if [ -f ./build/envsetup.sh ]; then
#	if [ "$TARGET_PRODUCT" != "bkos200" ] ; then
#		# --------------------------------------------
#		echo Init Script Start ........
#		if [ -f ./build/envsetup.sh ]; then
#			. build/envsetup.sh
#			lunch 12
#		fi
#	fi
#else
#	echo "Please Check the bkos200 source path!!!!"
#	exit 0
#fi

#--------------------------------------------------------------------------------------------------

echo Current Path : `pwd`
echo "*********************************************"
echo "           Select Build Operator             "
echo "*===========================================*"
echo "  1 or linux_all : Kernel Build              "
echo "  2 or amp_core  : AMP Core build            "
echo "  3 or sdk       : MV88DE3100 SDK build      "
echo "  4 or googletv  : GoogleTV Feature build    "
echo "  5 or emmc      : Make the eMMC Image       "
echo "  6 or otap      : OTA Package Build         "
echo "  7 or mp        : Mass Production Build     "
echo "  0 or all       :                           "
echo "*===========================================*"
echo "           repo init/sync/clean/fetch        "
echo "*===========================================*"
echo "  51 or init     : repo init                 "
echo "  52 or sync     : repo sync                 "
echo "  53             : repo init & sync          "
echo "  54 or clean    : clean                     "
echo "*===========================================*"
echo "           repo branch                       "
echo "*===========================================*"
echo "  b ro branch                                "
echo "*===========================================*"
echo "  release                                    "
echo "*===========================================*"
echo "  x: Exit                                   *"
echo "============================================*"
echo "Select : "
read Choice_Command
echo "*********************************************"

# =============================================================================

if [ -z $Choice_Command  ] ; then
	Choice_Command='x'
fi

# =============================================================================

if [ $Choice_Command == 'x' ] || [ $Choice_Command == 'X' ] ; then
	echo Exit ........
fi

# =============================================================================

if [ $Choice_Command == 'clean_need_to_check' ] ; then

	echo Clean Start ........

	logfile_name=$temp_current_directory/build_clean_proc.log
	logfile_name_old=$temp_current_directory/build_clean_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	echo Build started at $(date) | tee -a $logfile_name

	echo "# repo forall -c git clean -d -f"
	repo forall -c git clean -d -f
	echo "# Done 1 ........... repo forall -c git clean -d -f"
	echo "# forall -c git reset --hard HEAD"
	repo forall -c git reset --hard HEAD
	echo "# Done 2 ........... forall -c git reset --hard HEAD"
	echo "# forall -c git checkout m/master"
	repo forall -c git checkout m/master
	echo "# Done 3 ........... forall -c git checkout m/master"
	echo "# repo sync"
	repo sync
	echo "# Done 4 ........... repo sync"
	
	echo Build completed at $(date) | tee -a $logfile_name

	echo android Clean Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'inittttttttt' ] ; then

	# --------------------------------------------
	HO_BUILD_ENV_INIT_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '0' ] || [ $Choice_Command == 'all' ] ; then

	# --------------------------------------------
	HO_REPO_BRANCH_
	HO_BUILD_ENV_INIT_
	HO_BUILD_ALL_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '1' ] || [ $Choice_Command == 'linux_all' ] ; then

	# --------------------------------------------
	HO_BUILD_ENV_INIT_
	HO_BUILD_LINUX_ALL_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '2' ] || [ $Choice_Command == 'amp_core' ] ; then

	# --------------------------------------------
	HO_BUILD_ENV_INIT_
	HO_BUILD_AMP_CORE_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '3' ] || [ $Choice_Command == 'sdk' ] ; then

	# --------------------------------------------
	HO_BUILD_ENV_INIT_
	HO_BUILD_SDK_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '4' ] || [ $Choice_Command == 'googletv' ] ; then

	# --------------------------------------------
	HO_BUILD_ENV_INIT_
	HO_BUILD_GOOGLETV_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '5' ] || [ $Choice_Command == 'emmc' ] ; then

	# --------------------------------------------
	HO_BUILD_ENV_INIT_
	HO_BUILD_EMMC_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '6' ] || [ $Choice_Command == 'ota' ] ; then

	# --------------------------------------------
	HO_BUILD_ENV_INIT_
	HO_BUILD_OTA_PACKAGE_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '7' ] || [ $Choice_Command == 'mp' ] ; then

	# --------------------------------------------
	HO_BUILD_ENV_INIT_
	HO_BUILD_MP_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '51' ] || [ $Choice_Command == 'init' ] ; then

	# --------------------------------------------
	HO_REPO_INIT_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '52' ] || [ $Choice_Command == 'sync' ] ; then

	# --------------------------------------------
	HO_REPO_SYNC_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '53' ] ; then

	# --------------------------------------------
	HO_REPO_INIT_
	HO_REPO_SYNC_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '54' ] || [ $Choice_Command == 'clean' ] ; then

	# --------------------------------------------
	HO_REPO_CLEAN_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == 'b' ] || [ $Choice_Command == 'branch' ] ; then

	# --------------------------------------------
	HO_REPO_BRANCH_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == 'full' ] || [ $Choice_Command == 'FULL' ] ; then

	# --------------------------------------------
	HO_REPO_INIT_
	HO_REPO_SYNC_
	HO_REPO_BRANCH_
	HO_BUILD_ENV_INIT_
	HO_BUILD_ALL_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == 'releaseeeeeeeeeeee' ] ; then

	# --------------------------------------------
	HO_REPO_INIT_
	HO_REPO_SYNC_
	HO_REPO_BRANCH_

	# OTA
	HO_CHANGE_BKOS200_CONFIG_OTA_

	HO_BUILD_ENV_INIT_
	HO_BUILD_ALL_
	#HO_BUILD_MP_
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == 'ho1' ] ; then

	# --------------------------------------------
	HO_HOKIM_UPDATE_ZIP_
	# --------------------------------------------

fi

# =============================================================================


# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
