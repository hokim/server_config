#!/bin/sh
# =============================================================================

# --------------------------------------------
	echo "TVStorm repository ***********************"
# --------------------------------------------
	echo "repo start master kaon/googletv/v4-rc-81358"
	repo start master kaon/googletv/v4-rc-81358
	echo "repo start master kaon/bkos200"
	repo start master kaon/bkos200
	echo "repo start master kaon/marvell/sdk-marvell"
	repo start master kaon/marvell/sdk-marvell
	echo "repo start master tvstorm/prebuilts"
	repo start master tvstorm/prebuilts

# --------------------------------------------
	echo "Kaon repository ***********************"
# --------------------------------------------
	echo "repo start mrvl/bg2ct/OTA01 marvell/mv88de3100_sdk"
	repo start mrvl/bg2ct/OTA01 marvell/mv88de3100_sdk
	echo "repo start mrvl/bg2ct/OTA01 marvell/ampsdk"
	repo start mrvl/bg2ct/OTA01 marvell/ampsdk
	echo "repo start mrvl/bg2ct/OTA01 marvell/linux"
	repo start mrvl/bg2ct/OTA01 marvell/linux

# =============================================================================
echo The End.
# =============================================================================
