#!/bin/sh

#--------------------------------------------------------------------------------------------------

# --------------------------------------------
	echo All of the source Compile Start ........
	echo Build started at $(date)
# --------------------------------------------
	echo Init Script Start ........
	if [ -f ./build/envsetup.sh ]; then
		. build/envsetup.sh
		lunch 12
	else
		echo "Please Check the bkos200 source path!!!!"
		exit 0
	fi
	echo "############################"
	echo Init Script Completed ........
# --------------------------------------------
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo Kernel Build started at $(date)
	echo "####### Kernel build make linux_all #############"
	make linux_all
	echo Kernel Build completed at $(date)
# --------------------------------------------
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo AMP Core Build started at $(date)
	echo "####### amp_core build make amp_core #############"
	make amp_core
	echo AMP Core Build completed at $(date)
# --------------------------------------------
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo mv88de3100_sdk Build started at $(date)
	echo "####### mv88de3100_sdk build make mv88de3100_sdk #############"
	make mv88de3100_sdk
	echo mv88de3100_sdk Build completed at $(date)
# --------------------------------------------
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo GoogleTV Build started at $(date)
	echo "####### googletv build make -j8 #############"
	make -j8
	echo GoogleTV Build completed at $(date)
# --------------------------------------------
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo eMMC Image Build started at $(date)
	echo "####### eMMC Image build make image -j8 #############"
	make image -j8
	echo eMMC Image Build completed at $(date)
# --------------------------------------------
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo "############################"
	echo OTA Package Build started at $(date)
	echo "####### OTA Package Image build make otapackage -j8 #############"
	make otapackage -j8
	echo OTA Package Build completed at $(date)
# --------------------------------------------
	echo All of the source Compile Completed ........
# --------------------------------------------

# =============================================================================

echo The End.

# =============================================================================
