#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_directory=`pwd`
temp_current_path=$PATH
temp_default_module=anydata-lazydog
logfile_modem_path=.

#--------------------------------------------------------------------------------------------------

# Set Path
source ~/work_config/mdm9x25/setpath.sh

# =============================================================================

if [ -z $Choice_Command  ] ; then
	Choice_Command='x'
fi

# =============================================================================

if [ $Choice_Command == 'x' ] || [ $Choice_Command == 'X' ] ; then
	echo Exit ........
fi

# =============================================================================

if [ $Choice_Command == '0' ] || [ $Choice_Command == 'all' ] ; then
	# --------------------------------------------
	export PATH=$PYTHON266_PATH:$PATH

	echo All of the source Compile Start ........
	# --------------------------------------------
	echo Bootloader Compile Start ........

	logfile_name=$temp_current_directory/work_all.log
	logfile_name_old=$temp_current_directory/work_all.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	# --------------------------------------------
	echo Bootloader Compile ........
	cd $logfile_modem_path/boot_images/build/ms
	./build.sh boot BUILD_ID=ACETRMAZ | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo RPM Compile ........
	cd $logfile_modem_path/rpm_proc/build
	./build_9x15.sh | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	echo Modem Compile ........
	cd $logfile_modem_path/modem_proc/build/ms
	./build.sh mpss BUILD_ID=ACETWMAZ | tee -a $logfile_name
	cd $temp_current_directory
	export PATH=$temp_current_path

	# --------------------------------------------
	export PATH=$PYTHON273_PATH:$PATH
	echo Apps Compile ........
	cd $logfile_modem_path/apps_proc
	./build.sh | tee -a $logfile_name
	echo Build completed at $(date) | tee -a $logfile_name
	cd $temp_current_directory
	
	# --------------------------------------------
	echo All of the source Compile Completed ........
fi

# =============================================================================

#if [ $Choice_Command == '1' ] || [ $Choice_Command == 'boot' ] ; then
if [ $Choice_Command == 'boot' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo Boot_Loader Compile Start ........

	logfile_name=$temp_current_directory/work_boot_images.log
	logfile_name_old=$temp_current_directory/work_boot_images.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/boot_images/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh boot BUILD_ID=ACETRMAZ | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo Boot_Loader Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

#if [ $Choice_Command == '2' ] || [ $Choice_Command == 'rpm' ] ; then
if [ $Choice_Command == 'rpm' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo RPM Compile Start ........

	logfile_name=$temp_current_directory/work_rpm_proc.log
	logfile_name_old=$temp_current_directory/work_rpm_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/rpm_proc/build
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build_9x15.sh | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo RPM Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

#if [ $Choice_Command == '3' ] || [ $Choice_Command == 'modem' ] ; then
if [ $Choice_Command == 'dsp' ] || [ $Choice_Command == 'modem' ] ; then
	export PATH=$PYTHON266_PATH:$PATH

	echo Modem Compile Start ........

	logfile_name=$temp_current_directory/work_modem_proc.log
	logfile_name_old=$temp_current_directory/work_modem_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/modem_proc/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh mpss BUILD_ID=ACETWMAZ | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo Modem Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

#if [ $Choice_Command == '4' ] || [ $Choice_Command == 'apps' ] ; then
if [ $Choice_Command == 'apps' ] ; then
	export PATH=$PYTHON273_PATH:$PATH

	echo Apps Compile Start ........

	logfile_name=$temp_current_directory/work_apps_proc.log
	logfile_name_old=$temp_current_directory/work_apps_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	BUILD_CMD="build9625"

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		${BUILD_CMD} | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Apps Compile Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'mc' ] || [ $Choice_Command == 'mclean' ] ; then

	echo Module Clean Start ........

	echo "Input the module name : "
	read Ho_Module_Name

	if [ "$Ho_Module_Name" = "" ] ; then
		Ho_Module_Name=$temp_default_module
	fi

	Ho_Build_Log_Name=$Ho_Module_Name
	if [ "$Ho_Build_Log_Name" = "virtual/kernel" ] ; then
		Ho_Build_Log_Name=kernel
	fi
	if [ "$Ho_Build_Log_Name" = "virtual/bootloader" ] ; then
		Ho_Build_Log_Name=bootloader
	fi

	# --------------------------------------------

	if [ "$Ho_Module_Name" = "kernel" ] ; then
		Ho_Module_Name=virtual/kernel
	fi

	if [ "$Ho_Module_Name" = "bootloader" ] ; then
		Ho_Module_Name=virtual/bootloader
	fi

	# --------------------------------------------

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_clean_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_clean_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake -c cleanall $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Clean $Ho_Module_Name Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'mb' ] || [ $Choice_Command == 'mbuild' ] ; then

	echo Module Build Start ........

	echo "Input the module name : "
	read Ho_Module_Name

	if [ "$Ho_Module_Name" = "" ] ; then
		Ho_Module_Name=$temp_default_module
	fi

	Ho_Build_Log_Name=$Ho_Module_Name
	if [ "$Ho_Build_Log_Name" = "virtual/kernel" ] ; then
		Ho_Build_Log_Name=kernel
	fi
	if [ "$Ho_Build_Log_Name" = "virtual/bootloader" ] ; then
		Ho_Build_Log_Name=bootloader
	fi

	# --------------------------------------------

	if [ "$Ho_Module_Name" = "kernel" ] ; then
		Ho_Module_Name=virtual/kernel
	fi

	if [ "$Ho_Module_Name" = "bootloader" ] ; then
		Ho_Module_Name=virtual/bootloader
	fi

	# --------------------------------------------

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Build $Ho_Module_Name Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'mcb' ] ; then

	echo Module Clean and Build Start ........

	echo "Input the module name : "
	read Ho_Module_Name

	if [ "$Ho_Module_Name" = "" ] ; then
		Ho_Module_Name=$temp_default_module
	fi

	Ho_Build_Log_Name=$Ho_Module_Name
	if [ "$Ho_Build_Log_Name" = "virtual/kernel" ] ; then
		Ho_Build_Log_Name=kernel
	fi
	if [ "$Ho_Build_Log_Name" = "virtual/bootloader" ] ; then
		Ho_Build_Log_Name=bootloader
	fi

	# --------------------------------------------

	if [ "$Ho_Module_Name" = "kernel" ] ; then
		Ho_Module_Name=virtual/kernel
	fi

	if [ "$Ho_Module_Name" = "bootloader" ] ; then
		Ho_Module_Name=virtual/bootloader
	fi

	# --------------------------------------------

	echo Module Clean Start ........

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_clean_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_clean_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake -c cleanall $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Clean $Ho_Module_Name Completed ........

	cd $temp_current_directory

	# --------------------------------------------

	echo Module Build Start ........

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Build $Ho_Module_Name Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'cleanalllllllllllllllllllllllll' ] ; then

	echo All of Module Clean Start ........

	cd $logfile_modem_path/apps_proc/oe-core
	rm -rf ./build/tmp-eglibc
	mkdir ./build/tmp-eglibc

	echo All of Module Clean Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'partition' ] ; then

	echo Partition Build Start ........

	cd $logfile_modem_path/common/build
	python ./update_common_info.py

	echo Partition Build Completed ........

	cd $temp_current_directory
fi

# =============================================================================

#if [ $Choice_Command == '7' ] || [ $Choice_Command == 'em' ] ; then
if [ $Choice_Command == 'em' ] ; then

	echo Copy - Emergency Download Images Start ........

	if [ -d ./Emergency_Download_Images ]; then
		echo Erase the Emergency_Download_Images folder ...
		rm -rf ./Emergency_Download_Images
	fi
	
	mkdir ./Emergency_Download_Images
	cp -pf ./boot_images/build/ms/bin/ACETRMAZ/*.mbn ./Emergency_Download_Images/
	#cp -pf ./boot_images/build/ms/bin/ACETRMAZ/*.bin ./Emergency_Download_Images/
	cp -pf ./boot_images/build/ms/bin/ACETRMAZ/*.hex ./Emergency_Download_Images/
	cp -pf ./rpm_proc/build/ms/bin/AAAAANAAR/*.mbn ./Emergency_Download_Images/
	cp -pf ./common/build/partition.mbn ./Emergency_Download_Images/
	cp -pf ./modem_proc/build/ms/bin/ACETWMAZ/*.mbn ./Emergency_Download_Images/
	cp -pf ./apps_proc/oe-core/build/tmp-eglibc/deploy/images/9615-cdp/*.mbn ./Emergency_Download_Images/
	#cp -pf ./apps_proc/oe-core/build/tmp-eglibc/deploy/images/9615-cdp/*.img ./Emergency_Download_Images/
	cp -pf ./apps_proc/oe-core/build/tmp-eglibc/deploy/images/9615-cdp/boot-*.img ./Emergency_Download_Images/
	#cp -pf ./apps_proc/oe-core/build/tmp-eglibc/deploy/images/9615-cdp/9615-cdp-*.yaffs2 ./Emergency_Download_Images/
	cp -pf ./apps_proc/oe-core/build/tmp-eglibc/deploy/images/9615-cdp/9615-cdp-image*.yaffs2 ./Emergency_Download_Images/
	cp -pf ./apps_proc/oe-core/build/tmp-eglibc/deploy/images/9615-cdp/9615-cdp-usr*.yaffs2 ./Emergency_Download_Images/
	cp -pf ./apps_proc/oe-core/build/tmp-eglibc/deploy/images/9615-cdp/9615-cdp-cdrom*.yaffs2 ./Emergency_Download_Images/
	cp -pf ./apps_proc/oe-core/build/tmp-eglibc/work/9615_cdp-oe-linux-gnueabi/linux-quic-git-*/linux-quic-obj/vmlinux ./Emergency_Download_Images/
	cp -pf ./apps_proc/oe-core/build/tmp-eglibc/work/9615_cdp-oe-linux-gnueabi/linux-quic-git-*/linux-quic-obj/vmlinux.o ./Emergency_Download_Images/
	cp -pf ./apps_proc/oe-core/build/tmp-eglibc/work/9615_cdp-oe-linux-gnueabi/linux-quic-git-*/linux-quic-obj/System.map ./Emergency_Download_Images/

	chmod a+x ./boot_images/core/storage/flash/tools/src/nand/nand_tools
	./boot_images/core/storage/flash/tools/src/nand/nand_tools -fp 2048 -fb 64 -fd 1024 -u partition.mbn -d sbl1.mbn -m mibib.mbn -p ./Emergency_Download_Images

	echo Copy - Emergency Download Images Completed ........

fi

# =============================================================================

if [ $Choice_Command == '9' ] || [ $Choice_Command == 'permission' ] ; then

	echo Permission Setting Start ........
	#cd $logfile_modem_path

	find . -name "*.sh" -exec sudo chmod a+x {} \;
	find . -name "*.pl" -exec sudo chmod a+x {} \;
	find . -name "*.cmd" -exec sudo chmod a+x {} \;
	#find . -name "*.py" -exec sudo chmod a+x {} \;

	echo Permission Setting Completed ........

fi

# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
