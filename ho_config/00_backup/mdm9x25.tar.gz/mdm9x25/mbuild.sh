#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_directory=`pwd`
temp_current_path=$PATH
temp_default_module=anydata-lazydog
logfile_modem_path=.

#--------------------------------------------------------------------------------------------------

# Set Path
source ~/work_config/mdm9x25/setpath.sh

# =============================================================================

	echo Module Build Start ........

	echo "Input the module name : "
	read Ho_Module_Name

	if [ "$Ho_Module_Name" = "" ] ; then
		Ho_Module_Name=$temp_default_module
	fi

	Ho_Build_Log_Name=$Ho_Module_Name
	if [ "$Ho_Build_Log_Name" = "virtual/kernel" ] ; then
		Ho_Build_Log_Name=kernel
	fi
	if [ "$Ho_Build_Log_Name" = "virtual/bootloader" ] ; then
		Ho_Build_Log_Name=bootloader
	fi

	# --------------------------------------------

	if [ "$Ho_Module_Name" = "kernel" ] ; then
		Ho_Module_Name=virtual/kernel
	fi

	if [ "$Ho_Module_Name" = "bootloader" ] ; then
		Ho_Module_Name=virtual/bootloader
	fi

	# --------------------------------------------

	echo Module : $Ho_Module_Name

	logfile_name=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log
	logfile_name_old=$temp_current_directory/work_module_build_$Ho_Build_Log_Name.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		bitbake $Ho_Module_Name | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Module Build $Ho_Module_Name Completed ........

	cd $temp_current_directory

# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
