#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_directory=`pwd`
temp_current_path=$PATH
logfile_path=.

#--------------------------------------------------------------------------------------------------

# Set Path
#source ~/ho_config/avr900/setpath.sh

#--------------------------------------------------------------------------------------------------

if [ -f ./build/envsetup.sh ]; then
	if [ "$TARGET_PRODUCT" != "bkos200" ] ; then
		# --------------------------------------------
		echo Init Script Start ........
		if [ -f ./build/envsetup.sh ]; then
			. build/envsetup.sh
			lunch 12
		fi
	fi
else
	echo "Please Check the bkos200 source path!!!!"
	exit 0
fi

echo Current Path : `pwd`
echo "**************************************************************************"
echo "*              S e l e c t   B u i l d   O p e r a t o r                 *"
echo "*========================================================================*"
echo "*  1 or linux_all : Kernel Build                                         *"
echo "*  2 or amp_core  : AMP Core build                                       *"
echo "*  3 or sdk       : MV88DE3100 SDK build                                 *"
echo "*  4 or googletv  : GoogleTV Feature build                               *"
echo "*  5 or emmc      : Make the eMMC Image                                  *"
echo "*  6 or otap      : OTA Package Build                                    *"
echo "*  7 or mp        : Mass Production Build                                *"
#echo "*  9 or make_images or em :                                              *"
#echo "*  10 or cp_images        :                                              *"
echo "*  0 or all       :                                                      *"
echo "*------------------------------------------------------------------------*"
#echo "*  em - Emergency Download Images                                        *"
echo "*  99 or permission : Permission Setting(*.pl,*.cmd,*.sh)                *"
echo "*------------------------------------------------------------------------*"
echo "*  x: Exit                                                               *"
echo "*========================================================================*"
echo "Select : "
read Choice_Command
echo "**************************************************************************"

# =============================================================================

if [ -z $Choice_Command  ] ; then
	Choice_Command='x'
fi

# =============================================================================

if [ $Choice_Command == 'x' ] || [ $Choice_Command == 'X' ] ; then
	echo Exit ........
fi

# =============================================================================

if [ $Choice_Command == 'clean_need_to_check' ] ; then

	echo Clean Start ........

	logfile_name=$temp_current_directory/build_clean_proc.log
	logfile_name_old=$temp_current_directory/build_clean_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	echo Build started at $(date) | tee -a $logfile_name

	echo "# repo forall -c git clean -d -f"
	repo forall -c git clean -d -f
	echo "# Done 1 ........... repo forall -c git clean -d -f"
	echo "# forall -c git reset --hard HEAD"
	repo forall -c git reset --hard HEAD
	echo "# Done 2 ........... forall -c git reset --hard HEAD"
	echo "# forall -c git checkout m/master"
	repo forall -c git checkout m/master
	echo "# Done 3 ........... forall -c git checkout m/master"
	echo "# repo sync"
	repo sync
	echo "# Done 4 ........... repo sync"
	
	echo Build completed at $(date) | tee -a $logfile_name

	echo android Clean Completed ........

	cd $temp_current_directory
fi

# =============================================================================

if [ $Choice_Command == 'init' ] ; then

	# --------------------------------------------
	cd $logfile_path
	# --------------------------------------------
	echo Init Script Start ........
	if [ -f ./build/envsetup.sh ]; then
		. build/envsetup.sh
		lunch 12
	fi
	cd $temp_current_directory
	echo Init Script Completed ........
	# --------------------------------------------
fi

# =============================================================================

if [ $Choice_Command == '0' ] || [ $Choice_Command == 'all' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_all.log
	logfile_name_old=$temp_current_directory/build_all.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo All of the source Compile Start ........ | tee -a $logfile_name
	. ~/ho_config/bko-s200/bkos200_all.sh 2>&1 | tee -a $logfile_name
	cd $temp_current_directory
	echo All of the source Compile Completed ........ | tee -a $logfile_name
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '1' ] || [ $Choice_Command == 'linux_all' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_kernel_proc.log
	logfile_name_old=$temp_current_directory/build_kernel_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Kernel Compile Started ........ | tee -a $logfile_name
	. ~/ho_config/bko-s200/bkos200_kernel.sh 2>&1 | tee -a $logfile_name
	cd $temp_current_directory
	echo Kernel Compile Completed ........ | tee -a $logfile_name
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '2' ] || [ $Choice_Command == 'amp_core' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_amp_core_proc.log
	logfile_name_old=$temp_current_directory/build_amp_core_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo AMP Core Compile Started ........ | tee -a $logfile_name
	. ~/ho_config/bko-s200/bkos200_amp_core.sh 2>&1 | tee -a $logfile_name
	cd $temp_current_directory
	echo AMP Core Compile Completed ........ | tee -a $logfile_name
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '3' ] || [ $Choice_Command == 'sdk' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_mv88de3100_sdk_proc.log
	logfile_name_old=$temp_current_directory/build_mv88de3100_sdk_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo MV88DE3100 SDK Compile Started ........ | tee -a $logfile_name
	. ~/ho_config/bko-s200/bkos200_sdk.sh 2>&1 | tee -a $logfile_name
	cd $temp_current_directory
	echo MV88DE3100 SDK Compile Completed ........ | tee -a $logfile_name
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '4' ] || [ $Choice_Command == 'googletv' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_googletv_proc.log
	logfile_name_old=$temp_current_directory/build_googletv_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo GoogleTV Compile Started ........ | tee -a $logfile_name
	. ~/ho_config/bko-s200/bkos200_googletv.sh 2>&1 | tee -a $logfile_name
	cd $temp_current_directory
	echo GoogleTV Compile Completed ........ | tee -a $logfile_name
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '5' ] || [ $Choice_Command == 'emmc' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_emmc_proc.log
	logfile_name_old=$temp_current_directory/build_emmc_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo eMMC Image Make Started ........ | tee -a $logfile_name
	. ~/ho_config/bko-s200/bkos200_emmc.sh 2>&1 | tee -a $logfile_name
	cd $temp_current_directory
	echo eMMC Image Make Completed ........ | tee -a $logfile_name
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '6' ] || [ $Choice_Command == 'otap' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_ota_package_proc.log
	logfile_name_old=$temp_current_directory/build_ota_package_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo OTA Package Compile Started ........ | tee -a $logfile_name
	. ~/ho_config/bko-s200/bkos200_ota.sh 2>&1 | tee -a $logfile_name
	cd $temp_current_directory
	echo OTA Package Compile Completed ........ | tee -a $logfile_name
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '7' ] || [ $Choice_Command == 'mp' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/build_mp_proc.log
	logfile_name_old=$temp_current_directory/build_mp_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Mass Production Compile Started ........ | tee -a $logfile_name
	. ~/ho_config/bko-s200/bkos200_mp.sh 2>&1 | tee -a $logfile_name
	cd $temp_current_directory
	echo Mass Production Compile Completed ........ | tee -a $logfile_name
	# --------------------------------------------

fi

# =============================================================================
# =============================================================================
# =============================================================================

if [ $Choice_Command == 'cleanalllllllllllllllllllllllll' ] ; then

	echo All of Module Clean Start ........

	cd $logfile_path/apps_proc/oe-core
	rm -rf ./build/tmp-eglibc
	mkdir ./build/tmp-eglibc

	echo All of Module Clean Completed ........

	cd $temp_current_directory
fi

# =============================================================================
# =============================================================================
# =============================================================================

if [ $Choice_Command == '99' ] || [ $Choice_Command == 'permission' ] ; then

	echo Permission Setting Start ........
	#cd $logfile_path

	find . -name "*.sh" -exec sudo chmod a+x {} \;
	find . -name "*.pl" -exec sudo chmod a+x {} \;
	find . -name "*.cmd" -exec sudo chmod a+x {} \;
	#find . -name "*.py" -exec sudo chmod a+x {} \;

	echo Permission Setting Completed ........

fi

# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
