#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_directory=`pwd`
temp_current_path=$PATH
temp_default_manifest=ssh://ottsrc.kaon:29418/marvell/manifest-combi-bkos200
logfile_path=.

#--------------------------------------------------------------------------------------------------

echo Current Path : `pwd`
echo "************************"
echo "*   Select  Operator   *"
echo "*======================*"
echo "*  0 or all(init,sync) *"
echo "*  1 or repo init      *"
echo "*  2 or repo sync      *"
echo "*----------------------*"
#echo "*  repo fetch          *"
#echo "*----------------------*"
#echo "*  3 or tvstorm        *"
#echo "*  4 or kaon           *"
#echo "*----------------------*"
echo "*  b or branch         *"
echo "*  c or clean          *"
echo "*----------------------*"
echo "*  x: Exit             *"
echo "*======================*"
echo "Select : "
read Choice_Command
echo "*******************"

# =============================================================================

if [ -z $Choice_Command  ] ; then
	Choice_Command='x'
fi

# =============================================================================

if [ $Choice_Command == 'x' ] || [ $Choice_Command == 'X' ] ; then
	echo Exit ........
fi

# =============================================================================

if [ $Choice_Command == '0' ] || [ $Choice_Command == 'all' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_all_proc.log
	logfile_name_old=$temp_current_directory/repo_all_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Repo Init Start ........ | tee -a $logfile_name
	repo init -u $temp_default_manifest 2>&1 | tee -a $logfile_name
	echo Repo Init Completed ........ | tee -a $logfile_name

	echo Repo Sync Start ........ | tee -a $logfile_name
	repo sync 2>&1 | tee -a $logfile_name
	echo Repo Sync Completed ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '1' ] || [ $Choice_Command == 'init' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_init_proc.log
	logfile_name_old=$temp_current_directory/repo_init_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Repo Init Start ........ | tee -a $logfile_name
	repo init -u $temp_default_manifest 2>&1 | tee -a $logfile_name
	echo Repo Init Completed ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == '2' ] || [ $Choice_Command == 'sync' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_sync_proc.log
	logfile_name_old=$temp_current_directory/repo_sync_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Repo Sync Start ........ | tee -a $logfile_name
	repo sync 2>&1 | tee -a $logfile_name
	echo Repo Sync Completed ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == 'b' ] || [ $Choice_Command == 'branch' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_branch_proc.log
	logfile_name_old=$temp_current_directory/repo_branch_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Branch Set Start ........ 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo "TVStorm repository ***********************" 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo "repo start master kaon/googletv/v4-rc-81358" 2>&1 | tee -a $logfile_name
	repo start master kaon/googletv/v4-rc-81358 2>&1 | tee -a $logfile_name
	echo "repo start master kaon/bkos200" 2>&1 | tee -a $logfile_name
	repo start master kaon/bkos200 2>&1 | tee -a $logfile_name
	echo "repo start master kaon/marvell/sdk-marvell" 2>&1 | tee -a $logfile_name
	repo start master kaon/marvell/sdk-marvell 2>&1 | tee -a $logfile_name
	echo "repo start master tvstorm/prebuilts" 2>&1 | tee -a $logfile_name
	repo start master tvstorm/prebuilts 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo "Kaon repository ***********************" 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	echo "repo start mrvl/bg2ct/OTA01 marvell/mv88de3100_sdk" 2>&1 | tee -a $logfile_name
	repo start mrvl/bg2ct/OTA01 marvell/mv88de3100_sdk 2>&1 | tee -a $logfile_name
	echo "repo start mrvl/bg2ct/OTA01 marvell/ampsdk" 2>&1 | tee -a $logfile_name
	repo start mrvl/bg2ct/OTA01 marvell/ampsdk 2>&1 | tee -a $logfile_name
	echo "repo start mrvl/bg2ct/OTA01 marvell/linux" 2>&1 | tee -a $logfile_name
	repo start mrvl/bg2ct/OTA01 marvell/linux 2>&1 | tee -a $logfile_name
	echo Branch Set Completed ........ 2>&1 | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == 'c' ] || [ $Choice_Command == 'clean' ] ; then

	# --------------------------------------------
	cd $logfile_path

	logfile_name=$temp_current_directory/repo_clean_proc.log
	logfile_name_old=$temp_current_directory/repo_clean_proc.log.old
	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi
	# --------------------------------------------
	echo Repo Clean Start ........ | tee -a $logfile_name
	repo forall -c git clean -d -f 2>&1 | tee -a $logfile_name
	repo forall -c git reset --hard HEAD 2>&1 | tee -a $logfile_name
	repo forall -c git checkout m/master 2>&1 | tee -a $logfile_name
	repo sync 2>&1 | tee -a $logfile_name
	echo Repo Clean Completed ........ | tee -a $logfile_name
	# --------------------------------------------
	cd $temp_current_directory
	# --------------------------------------------

fi

# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
