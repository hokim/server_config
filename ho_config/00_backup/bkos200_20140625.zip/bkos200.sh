#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_directory=`pwd`
temp_current_path=$PATH
temp_default_module=anydata-lazydog
logfile_path=.

#--------------------------------------------------------------------------------------------------

# Set Path
#source ~/ho_config/avr900/setpath.sh

#--------------------------------------------------------------------------------------------------

echo current_build_place=$current_build_place
echo ARMLMD_LICENSE_FILE=$ARMLMD_LICENSE_FILE
echo "**************************************************************************"
echo "*              S e l e c t   B u i l d   O p e r a t o r                 *"
echo "*========================================================================*"
echo "*  b or build     : Build                                                *"
echo "*  r or repo      :                                                      *"
echo "*------------------------------------------------------------------------*"
echo "*  99 or permission : Permission Setting(*.pl,*.cmd,*.sh)                *"
echo "*------------------------------------------------------------------------*"
echo "*  x: Exit                                                               *"
echo "*========================================================================*"
echo "Select : "
read Choice_Command
echo "**************************************************************************"

# =============================================================================

if [ -z $Choice_Command  ] ; then
	Choice_Command='x'
fi

# =============================================================================

if [ $Choice_Command == 'x' ] || [ $Choice_Command == 'X' ] ; then
	echo Exit ........
fi

# =============================================================================

if [ $Choice_Command == 'r' ] || [ $Choice_Command == 'repo' ] ; then

	# --------------------------------------------
	. ~/ho_config/bko-s200/bkos200_repo.sh
	# --------------------------------------------

fi

# =============================================================================

if [ $Choice_Command == 'b' ] || [ $Choice_Command == 'build' ] ; then

	# --------------------------------------------
	. ~/ho_config/bko-s200/bkos200_build.sh
	# --------------------------------------------

fi

# =============================================================================
# =============================================================================
# =============================================================================

if [ $Choice_Command == '99' ] || [ $Choice_Command == 'permission' ] ; then

	echo Permission Setting Start ........
	#cd $logfile_path

	find . -name "*.sh" -exec sudo chmod a+x {} \;
	find . -name "*.pl" -exec sudo chmod a+x {} \;
	find . -name "*.cmd" -exec sudo chmod a+x {} \;
	#find . -name "*.py" -exec sudo chmod a+x {} \;

	echo Permission Setting Completed ........

fi

# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
