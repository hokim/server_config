#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_directory=`pwd`
temp_current_path=$PATH
logfile_modem_path=.

#--------------------------------------------------------------------------------------------------

# Set Path
source ~/work_config/mdm9x25/setpath.sh

# =============================================================================

	export PATH=$PYTHON273_PATH:$PATH

	echo Apps Compile Start ........

	logfile_name=$temp_current_directory/work_android_proc.log
	logfile_name_old=$temp_current_directory/work_android_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	BUILD_CMD="build9625"

	cd $logfile_modem_path/apps_proc		
	if [ -f oe-core/build/conf/set_bb_env.sh ]; then
		cd oe-core
		. build/conf/set_bb_env.sh
		${BUILD_CMD} | tee -a $logfile_name
	fi

	echo Build completed at $(date) | tee -a $logfile_name

	echo Apps Compile Completed ........

	cd $temp_current_directory

# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
