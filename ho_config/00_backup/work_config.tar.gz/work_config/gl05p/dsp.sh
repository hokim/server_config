#!/bin/sh

#--------------------------------------------------------------------------------------------------

temp_current_directory=`pwd`
temp_current_path=$PATH
logfile_modem_path=.

#--------------------------------------------------------------------------------------------------

# Set Path
source ~/work_config/gl05p/setpath.sh

# =============================================================================

	export PATH=$PYTHON266_PATH:$PATH

	echo Modem Compile Start ........

	logfile_name=$temp_current_directory/work_modem_proc.log
	logfile_name_old=$temp_current_directory/work_modem_proc.log.old

	if [ -f $logfile_name_old ]; then
		rm -f $logfile_name_old
	fi
	if [ -f $logfile_name ]; then
		mv $logfile_name $logfile_name_old
	fi

	rm -f $logfile_name

	echo Build started at $(date) | tee -a $logfile_name

	cd $logfile_modem_path/modem_proc/build/ms
	if [ -f setenv.sh ]; then
		mv setenv.sh setenv_backup.sh
	fi
	./build.sh mpss BUILD_ID=ACETWMAZ | tee -a $logfile_name

	echo Build completed at $(date) | tee -a $logfile_name

	echo Modem Compile Completed ........

	cd $temp_current_directory

# =============================================================================

echo The End.
cd $temp_current_directory
export PATH=$temp_current_path

# =============================================================================
