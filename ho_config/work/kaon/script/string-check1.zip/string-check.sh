#!/bin/sh

test_test() {

	if [ ! -f $1 ]; then
		echo 0
		return;
	fi
	
	#grep -q "$2" $1 && echo $?
	#return
	if grep -qs "$2" $1
	then
		echo 1
	else
		echo 0
	fi
	return 1

}

#if [ -n test_test $1 ]; then
#	echo NULL
#else
#	echo OKOK
#fi

ddddddd=$(test_test $1 "new tagg")

echo $?
echo $ddddddd

