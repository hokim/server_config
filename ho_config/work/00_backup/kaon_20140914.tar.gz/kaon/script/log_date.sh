#!/bin/bash
cd /ssd2/home/hokim/archive/XX_daily_build
echo `date +%Y%m%d_%H%M%S` >> 1.log